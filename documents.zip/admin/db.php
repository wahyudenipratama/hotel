<?php
$con = mysqli_connect("localhost","root","","hotel") or die(mysqli_error($con));

?>